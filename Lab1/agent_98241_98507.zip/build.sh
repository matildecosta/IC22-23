#!/bin/bash

# make for c agents
cd ../build
 make robC1
 make robC2 
 make robC3 
