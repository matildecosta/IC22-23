/*
 * Rúben Saldanha
 * Matilde Costa
 * Assignment 1 - Challenge 2
 * RMI 2022-2023
 */


#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>

#include "RobSock.h"
#include "robfunc.h"

#define true 1
#define false 0
// Variaveis Globais////////////
struct pair
{ // como não existe pair em c, criei uma estrutura para o substituir
    int first;
    int second;
};

struct cell
{
    // Row and Column index of its parent
    // Note that 0 <= i <= ROW-1 & 0 <= j <= COL-1
    int parent_i, parent_j;
    // f = g + h
    double f, g, h;
};

struct pPair
{
    double f;
    struct pair a;
    bool b;
};

struct result
{
    int cost;
    struct pair path[300];
    int count;
};

const static int N = 10;
const static int M = 7;
static int samples[7][10] = {};                     // variavel que guarda os valores da line por célula
float maxVel = 0.1;
static char track[21][49] = {};
static int ind_y = 10, ind_x = 23;                  // coordenadas iniciais no mapa
static struct pair start_point = {10,23};

// Declaração Funções
void explore(int d);
int celula(int d, double pos, double cel);
void read_line(bool line[7]);
int need_turn(int d);
void print_data();
void print_sample();
void compress_data(int *data);
void little_adjustments();
int turn_left(int d);
int turn_right(int d);
int direction(double compass);
double distance(int d, double x, double y);
void shift_left(int a[], size_t n);
void clear_samples(); // pode não ser necessário, utilizei para tentar corrigir um erro
bool mapping(int d);
bool isUnBlocked(char grid[][49], int row, int col);
double calculateHValue(int row, int col, struct pair dest);
bool isValid(int row, int col);
void go_objective(int tmp_d, int elem);
struct result tracePath(struct cell cellDetails[21][49], struct pair dest, struct pair src);
bool isDestination(int row, int col, struct pair dest);
struct result aStarSearch(char grid[][49], struct pair src, struct pair dest);
struct result best_destination(char a[21][49],struct pair src);
bool check_path(int d);
void lost_paths();
void go_find(struct result values, struct pair scr);
bool move(int d, double pos, double cel);
int direction_objective(struct pair Path,struct pair src);

int main(int argc, char *argv[])
{
    char host[300] = "localhost";
    char rob_name[20] = "robsample";
    float lPow, rPow;
    float stop = 0.00;
    int state = STOP, stoppedState = RUN, rob_id = 1, time;
    char lmap[CELLROWS * 2 - 1][CELLCOLS * 2 - 1]; // in this map the center of cell (i,j), (i in 0..6, j in 0..13) is mapped to lmap[i*2][j*2].
                                                   // to know if there is a wall on top of cell(i,j) (i in 0..5), check if the value of lmap[i*2+1][j*2] is space or not

    printf(" Sample Robot\n Copyright (C) 2001-2019 Universidade de Aveiro\n");

    /* processing arguments */
    while (argc > 2) /* every option has a value, thus argc must be 1, 3, 5, ... */
    {
        if (strcmp(argv[1], "--host") == 0 || strcmp(argv[1], "-h") == 0)
        {
            strncpy(host, argv[2], 99);
            host[99] = '\0';
        }
        else if (strcmp(argv[1], "--robname") == 0 || strcmp(argv[1], "-r") == 0)
        {
            strncpy(rob_name, argv[2], 19);
            rob_name[19] = '\0';
        }
        else if (strcmp(argv[1], "--pos") == 0 || strcmp(argv[1], "-p") == 0)
        {
            if (sscanf(argv[2], "%d", &rob_id) != 1)
                argc = 0; /* error message will be printed */
        }
        else if (strcmp(argv[1], "--map") == 0 || strcmp(argv[1], "-m") == 0)
        {
            ReadMap(argv[2], lmap);
            for (int r = CELLROWS * 2 - 2; r >= 0; r--)
            {
                for (int c = 0; c < CELLCOLS * 2 - 1; c++)
                {
                    printf("%c", lmap[r][c]);
                }
                printf("\n");
            }
        }
        else
        {
            break; /* the while */
        }
        argc -= 2;
        argv += 2;
    }

    if (argc != 1)
    {
        fprintf(stderr, "Bad number of parameters\n"
                        "SYNOPSIS: mainRob [--host hostname] [--robname robotname] [--pos posnumber]\n");

        return 1;
    }

    /* Connect Robot to simulator */
    if (InitRobot(rob_name, rob_id, host) == -1)
    {
        printf("%s Failed to connect\n", rob_name);
        exit(1);
    }
    printf("%s Connected\n", rob_name);
    state = STOP;
    while (1)
    {

        /* Reading next values from Sensors */
        ReadSensors();

        /* show LineSensor values */
        bool line[7];
        GetLineSensor(line);
        // for(int i=0;i<N_LINE_ELEMENTS;i++) {
        // fprintf(stderr,"%s",line[i]?"1":"0");
        //}
        // fprintf(stderr,"\n");

        if (GetFinished()) /* Simulator has received Finish() or Robot Removed */
        {
            printf("%s Exiting\n", rob_name);
            exit(0);
        }
        if (state == STOP && GetStartButton())
            state = stoppedState; /* Restart     */
        if (state != STOP && GetStopButton())
        {
            stoppedState = state;
            state = STOP; /* Interrupt */
        }

        switch (state)
        {
        case RUN: /* Go */
            if (GetVisitingLed())
                state = WAIT;
            if (GetGroundSensor() == 0)
            { /* Visit Target */
                SetVisitingLed(true);
                printf("%s visited target at %d\n", rob_name, GetTime());
            }
            else
            {
                DetermineAction(0, &lPow, &rPow);
                DriveMotors(lPow, rPow);
            }
            break;
        case WAIT: /* Wait for others to visit target */
            SetReturningLed(true);
            if (GetVisitingLed())
                SetVisitingLed(false);
            if (GetReturningLed())
                state = RETURN;
            DriveMotors(0.0, 0.0);
            break;
        case RETURN: /* Return to home area */
            if (GetVisitingLed())
                SetVisitingLed(false);
            SetReturningLed(false);
            // Wander
            DetermineAction(1, &lPow, &rPow);
            DriveMotors(lPow, rPow);
        
            break;
        }
        initialize_track();
        explore(0);
        lost_paths();
        print_map();
        write_file();
        Finish();
        exit;
    }
    return 1;
}

void explore(int d)
{
    if (check_path(d))
    {
        // print_map();
        return;
    }
    int tmp_d = 4;
    double pos;
    double cel = 1.81;
    while (1)
    {       
        ReadSensors();
        if (mapping(d))
        {
            if(tmp_d != d){
                if(d == 0 || d == 2){
                    pos = GetX();
                    //printf("Valor de x: %lf\n", GetX());
                    cel = 1.81;
                    tmp_d = d;
                }
                else{
                    pos = GetY();
                    //printf("Valor de y: %lf\n", GetY());
                    cel = 1.81;                 //reset ao n. de celulas naquela direcao
                    tmp_d = d;
                }
                //funcao que me devolve a posicao inicial x ou y
            }
                                                //funcao para andar uma celula
            d = celula(d, pos, cel);            //move-se uma célula
            d = need_turn(d);
            cel = cel + 2;                      //mais uma celula
        }
        else
        {
            // printf("false\n");
            break;
        }
    }
    DriveMotors(0,0);
    //print_map();
    // printf("End\n");
    // printf("(%d,%d) \n", ind_y, ind_x);
    return;
}

void lost_paths()
{
    while (1)
    {
        struct pair src = {ind_y, ind_x};
        struct result rest = best_destination(track,src); // descobri o caminho mais proximo que quero explorar
        // for(size_t i=0; i <= rest.count; i++){
        //    printf("%d celulas na direçao %d\n", rest.path[i].second, rest.path[i].first);
        // }
        if(rest.cost > 300){
            return;
        }
        go_find(rest,src);
        // struct pair source = {ind_y, ind_x};
        // aStarSearch(track, source, destination);
        //print_map();
        DriveMotors(0,0);
    }
    // print_map();
    return ;
}

// andar célula a célula e registar valores
int celula(int d, double pos, double cel)
{
    int groundsensor = -1;
    while(move(d,pos,cel))
    { // 1 celula equivale a 2 unidades medida
        bool line[7];
        ReadSensors();
        GetLineSensor(line);                    // lê sensores linha
        little_adjustments(line);               // mantém o robot em cima da linha
        read_line(line);                        // guardar val. sensores de linha em matriz -> última posição
    }
    // print_sample();
    return d;
}

bool move(int d, double pos, double cel){
    switch(d){
        case(0):
            //printf("%f\n",GetX()-pos);
            if(GetX()-pos >= cel){
                return false;
            }
            break;
        case(1):
            //printf("%f\n",GetY()-pos);
            if(GetY()-pos >=  cel){
                return false;
            }
            break;
        case(2):
            //printf("%f\n",GetX()-pos);
            if(GetX()-pos <=  -cel){
                return false;
            }
            break;
        case(3):
            //printf("%f\n",GetY()-pos);
            if(GetY()-pos <=  -cel){
                return false;
            }
            break;
    }
    return true;
}


void read_line(bool line[M])
{
    for (size_t i = 0; i < M; i++)
        shift_left(samples[i], N);
    for (size_t i = 0; i < M; i++)
    {
        samples[i][N - 1] = (int)line[i];
    }
}

int need_turn(int d )
{
    int data[7] = {};
    // printf("d = %d\n",d);
    bool flag_l = 0, flag_r = 0, flag_s = 0;
    // print_sample();
    compress_data(data);
    // print_data(data);
    if (data[0] != 0)
    {
        flag_l = 1;
    }
    if (data[3] != 0 || data[4] != 0 || data[2] != 0)
    {
        flag_s = 1;
        if (flag_l)
        {
            mark('s', d);
        }
    }
    if (data[6] != 0)
    {
        flag_r = 1;
        if (flag_l || flag_s)
        { // se não tiver virado à esquerda vira à direita
            mark('r', d);
        }
    }
    if (flag_l)
    {
        d = turn_left(d);
    }
    else if (!flag_l && !flag_s && flag_r)
    {
        d = turn_right(d);
    }
    else if (!flag_l && !flag_s && !flag_r)
    {
        d = turn_around(d);
    }
    clear_samples();
    return d;
}

void print_data(int data[])
{
    for (size_t i = 0; i < 7; i++)
    {
        printf("%d\n", data[i]);
    }
}

void print_sample()
{
    for (size_t i = 0; i < M; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            printf("%d ", (samples[i][j]));
        }
        printf("\n");
    }
    printf("\n");
}

void compress_data(int *data)
{
    // printf("Compress_data\n");
    for (size_t i = 0; i < 2; i++)
    {
        data[i] = 0;
        for (size_t j = 0; j < N; j++)
        { // sensor esquerda
            data[i] += (int)(pow(2, (N - 1) - j) * samples[i][j]);
        }
    }
    for (size_t i = 2; i < 5; i++)
    { // sensor central
        data[i] = 0;
        for (size_t j = N - 1; j < N; j++)
        {
            data[i] += (int)(pow(2, (N - 1) - j) * samples[i][j]);
        }
    }
    for (size_t i = 5; i < M; i++)
    { // sensor direita
        data[i] = 0;
        for (size_t j = 0; j < N; j++)
        {
            data[i] += (int)(pow(2, (N - 1) - j) * samples[i][j]);
        }
    }
}

void little_adjustments(bool line[7])
{
    // printf("Little_adjustments\n");
    if (line[1] || line[2])
    {
        DriveMotors(0.6 * maxVel, maxVel);
        // printf("right smooth\n");
    }
    else if (line[5] || line[4])
    {
        DriveMotors(maxVel, 0.6 * maxVel);
        // printf("left smooth\n");
    }
    else if (line[2] && line[3] && line[4])
    { // XX111XX go straight
        // printf("Straight\n");
        DriveMotors(maxVel, maxVel);
    }
}

int turn_left(int d)
{
    double compass = GetCompassSensor();
    DriveMotors(-0.1, 0.1);
    switch (d)
    {
    case 0:
        while (GetCompassSensor() < 75)
        {
            ReadSensors();
        }
        d = 1;
        ind_x = ind_x + 1;
        ind_y = ind_y + 1;
        break;
    case 1:
        while (GetCompassSensor() < 165)
        {
            ReadSensors();
        }
        d = 2;
        ind_y--;
        ind_x++;
        break;
    case 2:
        while (abs(GetCompassSensor()) > 105)
        {
            ReadSensors();
        }
        d = 3;
        ind_y--;
        ind_x--;
        break;

    case 3:
        while (GetCompassSensor() < -15)
        {
            ReadSensors();
        }
        ind_y++;
        ind_x--;
        d = 0;
        break;
    }
    DriveMotors(0, 0);
    return d;
}

int turn_right(int d)
{
    double compass = GetCompassSensor();
    DriveMotors(0.1, -0.1);
    switch (d)
    {
    case 0:
        while (GetCompassSensor() > -75)
        {
            ReadSensors();
        }
        d = 3;
        ind_x++;
        ind_y--;
        break;
    case 1:
        while (GetCompassSensor() > 15)
        {
            ReadSensors();
        }
        d = 0;
        ind_y--;
        ind_x--;
        break;
    case 2:
        while (abs(GetCompassSensor()) > 105)
        {
            ReadSensors();
        }
        d = 1;
        ind_x--;
        ind_y++;
        break;
    case 3:
        while (GetCompassSensor() > -165)
        {
            ReadSensors();
        }
        ind_y++;
        ind_x++;
        d = 2;
        break;
    }
    DriveMotors(0, 0);
    return d;
}

double distance(int d, double x, double y)
{
    double dist;
    switch (d)
    {
    case 0:
        dist = GetX() - x;
        break;
    case 1:
        dist = GetY() - y;
        break;
    case 2:
        dist = x - GetX();
        break;
    case 3:
        dist = y - GetY();
        break;
    }
    return dist;
}

void shift_left(int a[], size_t n)
{
    if (n--)
    {
        memmove(a, a + 1, n * sizeof(*a));
        a[n] = 0;
    }
}

void clear_samples()
{
    for (size_t i; i < M; i++)
    {
        for (size_t j; j < N; j++)
        {
            samples[i][j] = 0;
        }
    }
}

bool mapping(int d)
{
    switch (d)
    {
    case 0:
        if ((track[ind_y][ind_x + 2] != '0' && track[ind_y][ind_x + 2] != ' ' && track[ind_y][ind_x + 2] != '*') || (track[ind_y][ind_x + 2] == '|' || track[ind_y][ind_x + 2] == '-'))
        {
            ind_x++;
            return false;
        }
        ind_x = ind_x + 2;
        track[ind_y][ind_x] = '-';
        track[ind_y][ind_x - 1] = ' ';
        break;
    case 1:
        if (track[ind_y - 2][ind_x] != '0' && track[ind_y - 2][ind_x] != ' ' && track[ind_y - 2][ind_x] != '*' || (track[ind_y - 2][ind_x] == '|' || track[ind_y - 2][ind_x] == '-'))
        {
            ind_y--;
            return false;
        }
        ind_y = ind_y - 2;
        track[ind_y][ind_x] = '|';
        track[ind_y + 1][ind_x] = ' ';
        break;
    case 2:
        if (track[ind_y][ind_x - 2] != '0' && track[ind_y][ind_x - 2] != ' ' && track[ind_y][ind_x - 2] != '*' || (track[ind_y][ind_x - 2] == '|' || track[ind_y][ind_x - 2] == '-'))
        {
            ind_x--;
            return false;
        }
        ind_x = ind_x - 2;
        track[ind_y][ind_x] = '-';
        track[ind_y][ind_x + 1] = ' ';
        break;
    case 3:
        if (track[ind_y + 2][ind_x] != '0' && track[ind_y + 2][ind_x] != ' ' && track[ind_y + 2][ind_x] != '*' || (track[ind_y + 2][ind_x] == '|' || track[ind_y + 2][ind_x] == '-'))
        {
            ind_y++;
            return false;
        }
        ind_y = ind_y + 2;
        track[ind_y][ind_x] = '|';
        track[ind_y - 1][ind_x] = ' ';
        break;
    }
    return true;
}

void print_map()
{
    printf("Imprimir mapa\n");
    for (size_t i = 0; i < 21; i++)
    {
        for (size_t j = 0; j < 49; j++)
        {
            printf("%c", track[i][j]);
        }
        printf("\n");
    }
}
void initialize_track()
{
    for (size_t i = 0; i < 21; i++)
    {
        for (size_t j = 0; j < 49; j++)
        {
            track[i][j] = '0';
        }
    }
}

void mark(char s, int d)
{
    switch (d)
    {
    case 0:
        if (s == 's' && track[ind_y][ind_x + 2] == '0')
        {
            track[ind_y][ind_x + 2] = '*';
        }
        else if (track[ind_y + 2][ind_x + 1] == '0')
        {
            track[ind_y + 1][ind_x + 1] = '*';
        }
        break;
    case 1:
        if (s == 's' && track[ind_y - 1][ind_x] == '0')
        {
            track[ind_y - 1][ind_x] = '*';
        }
        else if (track[ind_y - 1][ind_x + 2] == '0')
        {
            track[ind_y - 1][ind_x + 1] = '*';
        }
        break;
    case 2:
        if (s == 's' && track[ind_y][ind_x - 2] == '0')
        {
            track[ind_y][ind_x - 2] = '*';
        }
        else if (track[ind_y - 1][ind_x - 1] == '0')
        {
            track[ind_y - 1][ind_x - 1] = '*';
        }
        break;
    case 3:
        if (s == 's' && track[ind_y + 2][ind_x] == '0')
        {
            track[ind_y + 2][ind_x] = '*';
        }
        else if (track[ind_y + 1][ind_x - 1] == '0')
        {
            track[ind_y + 1][ind_x - 1] = '*';
        }
        break;
    }
}

int turn_around(int d)
{
    switch (d)
    {
    case 0:
        DriveMotors(-0.1, 0.1); // left
        while (GetCompassSensor() < 170)
        {
            ReadSensors();
        }
        ind_x = ind_x + 2;
        d = 2;
        break;
    case 1:
        DriveMotors(0.1, -0.1); // right
        while (GetCompassSensor() > -80)
        {
            ReadSensors();
        }
        d = 3;
        ind_y = ind_y - 2;
        break;
    case 2:
        DriveMotors(0.1, -0.1); // right
        while (abs(GetCompassSensor()) > 10)
        {
            ReadSensors();
        }
        d = 0;
        ind_x = ind_x - 2;
        break;
    case 3:
        DriveMotors(-0.1, 0.1); // left
        while (GetCompassSensor() < 80)
        {
            ReadSensors();
        }
        d = 1;
        ind_y = ind_y + 2;
        break;
    }
    DriveMotors(0, 0);
    return d;
}

int direction_objective(struct pair Path,struct pair src){
    if (src.first < Path.first) // tenho que andar para baixo
    {
        return 3;    
    }
    else if (src.first > Path.first) // andar para cima
    {
       return 1;
    }
    else if (src.second < Path.second) // andar para direita
    {
        return 0;
    }
    else // andar para esquerda
    {
        return 2;
    }
}



void go_objective(int tmp_d, int elem){
    ReadSensors();
    int d = direction(GetCompassSensor());
    //printf("%d\n",d);
     switch(tmp_d)
    {
        case(0):
            if (d != 0)
            { // ajustar posiçao/direçao do robot
                if (d == 1)
                {
                    d = turn_right(d); // direita
                    ind_x++;
                    ind_y++;
                }
                else if (d == 2)
                {
                    d = turn_around(d); // meia volta
                    ind_x = ind_x + 2;
                }
                else
                {
                    d = turn_left(d); // esquerda
                    ind_y--;
                    ind_x++;
                }
            }
            ReadSensors();
            if(elem!=0){
                celula(d, GetX(),1.81+2*(elem-1)); // move-se uma celula naquela direção
                ind_x = ind_x + 2*elem;
                return;
            }
            DriveMotors(0,0);
            break;
        case(1):
            if (d != 1)
            {
                if (d == 2)
                {
                    d = turn_right(d);
                    ind_x++;
                    ind_y--;
                }
                else if (d == 3)
                {
                    d = turn_around(d);
                    ind_y = ind_y - 2;
                }
                else
                {
                    d = turn_left(d);
                    ind_x = ind_x - 1;
                    ind_y = ind_y - 1;
                }
            }
            ReadSensors();
            if(elem!=0){
                celula(d, GetY(), 1.81+2*(elem-1)); // move-se uma celula naquela direção
                ind_y = ind_y - 2*elem;
                return;
            }
            DriveMotors(0,0);
            break;
        case(2):
            if (d != 2)
            {
                if (d == 1)
                {
                    d = turn_left(d);
                    ind_y++;
                    ind_x--;
                }
                else if (d == 3)
                {
                    d = turn_right(d);
                    ind_y--;
                    ind_x--;
                }
                else
                {
                    d = turn_around(d);
                    ind_x = ind_x - 2;
                }
            }
            ReadSensors();
            if(elem!=0){
                celula(d, GetX(), 1.81+2*(elem-1));
                ind_x = ind_x - 2*elem;
                return;
            }
            DriveMotors(0,0);
            break;
        case(3):
        if (d != 3)
        { // se nao for igual à pretendida gira
          // colocando o robot na posiçao pretendida
            if (d == 1)
            {
                d = turn_around(d); // meia volta
                ind_y = ind_y + 2;
            }
            else if (d == 2)
            {
                d = turn_left(d); // esquerda
                ind_y++;
                ind_x++;
            }
            else
            {
                d = turn_right(d); // direita
                ind_x--;
                ind_y++;
            }
        }
        ReadSensors();
        if(elem!=0){
            celula(d, GetY(),1.81+2*(elem-1));
            ind_y = ind_y + 2*elem;
            return;
        }
        DriveMotors(0,0);
        break;
    }
}

bool isUnBlocked(char grid[][49], int row, int col)
{
    // Returns true if the cell is not blocked else false
    if (grid[row][col] == ' ' || grid[row][col] == '-' || grid[row][col] == '|' || grid[row][col] == '*')
        return (true);
    else
        return (false);
}

double calculateHValue(int row, int col, struct pair dest) // distancia euclidiana se n estou em erro
{
    // Return using the distance formula
    return ((double)sqrt((row - dest.first) * (row - dest.first) + (col - dest.second) * (col - dest.second)));
}

bool isValid(int row, int col)
{
    // Returns true if row number and column number
    // is in range
    return (row >= 0) && (row < 21) && (col >= 0) && (col < 49);
}

int direction(double compass)
{
    int d;
    if (compass < 135 && compass > 45)
    {
        d = 1;
    }
    else if (compass > 135 || compass < -135)
    {
        d = 2;
    }
    else if (compass > -135 && compass < -45)
    {
        d = 3;
    }
    else
    {
        d = 0;
    }
    return d;
}
struct result tracePath(struct cell cellDetails[21][49], struct pair dest, struct pair src)
{
    printf("The Path is ");
    int row = dest.first;
    int col = dest.second;
    // printf("row = %d\ncol = %d\n", row, col);

    int counter = 0;
    struct pair Path[300];
    while (!(cellDetails[row][col].parent_i == row && cellDetails[row][col].parent_j == col))
    {
        Path[counter].first = row;
        Path[counter].second = col;
        int temp_row = cellDetails[row][col].parent_i;
        int temp_col = cellDetails[row][col].parent_j;
        row = temp_row;
        col = temp_col;
        counter++;
    }
    printf("%d\n", counter);
    bool final = 0;
    bool par = false;
    struct pair comp;   
    comp.first = src.first; comp.second = src.second;
    ReadSensors();
    int tmp_d = direction(GetCompassSensor()); 
    //double pos;go_obj
    int d;
    int cels = 0;
    struct pair values[300];
    for(size_t i=0; i < 300; i++){
        values[i].first = -1;
        values[i].second = -1;
    }
    int j = 0;
    int elem = 0;
    for (int i = counter - 1; i >= 0; i--)
    {
        //printf("-> (%d,%d) ", Path[i].first, Path[i].second);
        // printf("%d %d\n", ind_y, ind_x);
        if (i == 0) // verifica se chegámos ao final
        {
            final = 1;
        }

        if (par || final)
        {
            //enquanto o d se mantiver apenas vai somando o número de células a mover naquele posição
            d = direction_objective(Path[i], comp);
            if(tmp_d != d){
                elem++;
                values[j].first = tmp_d;
                values[j].second = cels; 
                tmp_d = d; 
                cels = 0;  
                j++;
                values[j].first = tmp_d;
                values[j].second = cels;  
            }
            else if(final){
                values[j].second = cels; 
                values[j].first = tmp_d;

            }
            cels++;
        //DriveMotors(0.005, 0.005);
        }
        par = !par;
        comp.first = Path[i].first; comp.second = Path[i].second;
    }
    struct result a;
    a.cost = counter;
    a.count = elem;
    int cont = 0;
    for(size_t i =0; i<300;i++){
        if(values[i].first < 0 || values[i].second <0){
            a.path[i].first = -1;
            a.path[i].second = -1;
            cont++;
        }
        else{
            a.path[i] = values[i];
        }
    }
    //printf("cont = %d\n",cont);
    // printf("\n////////Custo = %d////////\n", a.cost);
    // printf("////////Elemts = %d////////\n", a.count);
    // for(size_t i =0; i<300;i++){
    //     printf("(%d,%d) -> ", a.path[i].first, a.path[i].second);
    // }
    // printf("\n");
    return a;
    
}

bool isDestination(int row, int col, struct pair dest)
{
    if (row == dest.first && col == dest.second)
        return (true);
    else
        return (false);
}

struct result aStarSearch(char grid[][49], struct pair src, struct pair dest)
{
    struct result rest;
    rest.cost = __INT_MAX__;
    bool closedList[21][49];
    memset(closedList, false, sizeof(closedList));

    struct cell cellDetails[21][49];
    int i, j;

    // define que os parametros de todos os nós será o valor max - pelo menos por agora
    for (i = 0; i < 21; i++)
    {
        for (j = 0; j < 49; j++)
        {
            cellDetails[i][j].f = FLT_MAX;
            cellDetails[i][j].g = FLT_MAX;
            cellDetails[i][j].h = FLT_MAX;
            cellDetails[i][j].parent_i = -1;
            cellDetails[i][j].parent_j = -1;
        }
    }

    // Define os parametros do nó inicial
    i = src.first;
    j = src.second;
    cellDetails[i][j].f = 0.0;
    cellDetails[i][j].g = 0.0;
    cellDetails[i][j].h = 0.0;
    cellDetails[i][j].parent_i = i;
    cellDetails[i][j].parent_j = j;

    struct pPair openList[49];
    openList[0].f = 0.0;
    openList[0].a.first = i;
    openList[0].a.second = j;
    openList[0].b = true;
    bool foundDest = false;
    int iter = 0;
    int count = 0; // conta o n. de caminhos por iteraçao que explorámos
    while (openList[iter].b)
    { // verifica todas as posiçoes da openList através de uma flag(b)

        i = openList[iter].a.first;
        j = openList[iter].a.second;
        // printf("%d %d\n",i,j);
        openList[iter].b = false;
        closedList[i][j] = true;

        // To store the 'g', 'h'and 'f' of the 4 sucecessors;
        double gNew, hNew, fNew;

        // Norte
        if (isValid(i - 1, j) == true)
        {
            if (isDestination(i - 1, j, dest) == true)
            {
                // Set the Parent of the destination cell
                cellDetails[i - 1][j].parent_i = i;
                cellDetails[i - 1][j].parent_j = j;
                //printf("The destination cell is found\n");
                rest = tracePath(cellDetails, dest, src);
                foundDest = true;
                return rest;
            }
            else if (closedList[i - 1][j] == false && isUnBlocked(grid, i - 1, j) // se houver caminho e o nó não pertencer à closedList prossegue
                                                          == true)
            {
                // printf("Cima\n");
                gNew = cellDetails[i][j].g + 1.0;       // no primneiro caso g como é 0, 0+1=1
                hNew = calculateHValue(i - 1, j, dest); // calcula a distancia do eucleudiana do nó até ao destino
                fNew = gNew + hNew;                     //

                // If it isn’t on the open list, add it to
                // the open list. Make the current square
                // the parent of this square. Record the
                // f, g, and h costs of the square cell
                //			 OR
                // If it is on the open list already, check
                // to see if this path to that square is
                // better, using 'f' cost as the measure.
                if (cellDetails[i - 1][j].f == FLT_MAX // se o nó não existir ou se o caminho for menor adiciona-o à openList
                    || cellDetails[i - 1][j].f > fNew)
                {
                    count++;
                    openList[count].f = fNew;
                    openList[count].a.first = (i - 1);
                    openList[count].a.second = j;
                    openList[count].b = true;
                    // openList.insert(make_pair(
                    // 	fNew, make_pair(i - 1, j)));

                    // Atualiza os valores da célula
                    cellDetails[i - 1][j].f = fNew;
                    cellDetails[i - 1][j].g = gNew;
                    cellDetails[i - 1][j].h = hNew;
                    cellDetails[i - 1][j].parent_i = i;
                    cellDetails[i - 1][j].parent_j = j;
                }
            }
        }

        //////////////Sul///////////////////////////////////
        if (isValid(i + 1, j) == true)
        {
            // If the destination cell is the same as the
            // current successor
            if (isDestination(i + 1, j, dest) == true)
            {
                // Set the Parent of the destination cell
                cellDetails[i + 1][j].parent_i = i;
                cellDetails[i + 1][j].parent_j = j;
                //printf("The destination cell is found\n");
                rest = tracePath(cellDetails, dest, src); // tenho que acertar isto
                foundDest = true;
                return rest;
            }
            // If the successor is already on the closed
            // list or if it is blocked, then ignore it.
            // Else do the following
            else if (closedList[i + 1][j] == false && isUnBlocked(grid, i + 1, j) == true)
            {
                // printf("Baixo\n");
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i + 1, j, dest);
                fNew = gNew + hNew;

                // If it isn’t on the open list, add it to
                // the open list. Make the current square
                // the parent of this square. Record the
                // f, g, and h costs of the square cell
                //			 OR
                // If it is on the open list already, check
                // to see if this path to that square is
                // better, using 'f' cost as the measure.
                if (cellDetails[i + 1][j].f == FLT_MAX || cellDetails[i + 1][j].f > fNew)
                {
                    count++;
                    openList[count].f = fNew;
                    openList[count].a.first = (i + 1);
                    openList[count].a.second = j;
                    openList[count].b = true;
                    // openList.insert(make_pair(
                    // 	fNew, make_pair(i + 1, j)));
                    // Update the details of this cell
                    cellDetails[i + 1][j].f = fNew;
                    cellDetails[i + 1][j].g = gNew;
                    cellDetails[i + 1][j].h = hNew;
                    cellDetails[i + 1][j].parent_i = i;
                    cellDetails[i + 1][j].parent_j = j;
                }
            }
        }
        ///////////////////////Este//////////////////////
        // Only process this cell if this is a valid one
        if (isValid(i, j + 1) == true)
        {
            // If the destination cell is the same as the
            // current successor
            if (isDestination(i, j + 1, dest) == true)
            {
                // Set the Parent of the destination cell
                cellDetails[i][j + 1].parent_i = i;
                cellDetails[i][j + 1].parent_j = j;
                //printf("The destination cell is found\n");
                rest = tracePath(cellDetails, dest, src);
                foundDest = true;
                return rest;
            }

            // If the successor is already on the closed
            // list or if it is blocked, then ignore it.
            // Else do the following
            else if (closedList[i][j + 1] == false && isUnBlocked(grid, i, j + 1) == true)
            {
                // printf("Direita\n");
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i, j + 1, dest);
                fNew = gNew + hNew;
                // printf("gNew = %lf\n hNew = %lf\n fNew = %lf \n",gNew,hNew,fNew);

                // If it isn’t on the open list, add it to
                // the open list. Make the current square
                // the parent of this square. Record the
                // f, g, and h costs of the square cell
                //			 OR
                // If it is on the open list already, check
                // to see if this path to that square is
                // better, using 'f' cost as the measure.
                if (cellDetails[i][j + 1].f == FLT_MAX || cellDetails[i][j + 1].f > fNew)
                {
                    count++;
                    openList[count].f = fNew;
                    openList[count].a.first = (i);
                    openList[count].a.second = j + 1;
                    openList[count].b = true;
                    // openList.insert(make_pair(
                    // 	fNew, make_pair(i, j + 1)));

                    // Update the details of this cell
                    cellDetails[i][j + 1].f = fNew;
                    cellDetails[i][j + 1].g = gNew;
                    cellDetails[i][j + 1].h = hNew;
                    cellDetails[i][j + 1].parent_i = i;
                    cellDetails[i][j + 1].parent_j = j;
                }
            }
        }
        //////////////////////Oeste//////////////////
        // Only process this cell if this is a valid one
        if (isValid(i, j - 1) == true)
        {
            // If the destination cell is the same as the
            // current successor
            if (isDestination(i, j - 1, dest) == true)
            {
                // Set the Parent of the destination cell
                cellDetails[i][j - 1].parent_i = i;
                cellDetails[i][j - 1].parent_j = j;
                //printf("The destination cell is found\n");
                rest = tracePath(cellDetails, dest, src);
                foundDest = true;
                return rest;
            }

            // If the successor is already on the closed
            // list or if it is blocked, then ignore it.
            // Else do the following
            else if (closedList[i][j - 1] == false && isUnBlocked(grid, i, j - 1) == true)
            {
                // printf("Esquerda\n");
                gNew = cellDetails[i][j].g + 1.0;
                hNew = calculateHValue(i, j - 1, dest);
                fNew = gNew + hNew;

                // If it isn’t on the open list, add it to
                // the open list. Make the current square
                // the parent of this square. Record the
                // f, g, and h costs of the square cell
                //			 OR
                // If it is on the open list already, check
                // to see if this path to that square is
                // better, using 'f' cost as the measure.
                if (cellDetails[i][j - 1].f == FLT_MAX || cellDetails[i][j - 1].f > fNew)
                {
                    count++;
                    openList[count].f = fNew;
                    openList[count].a.first = (i);
                    openList[count].a.second = j - 1;
                    openList[count].b = true;
                    // openList.insert(make_pair(
                    // 	fNew, make_pair(i, j - 1)));

                    // Update the details of this cell
                    cellDetails[i][j - 1].f = fNew;
                    cellDetails[i][j - 1].g = gNew;
                    cellDetails[i][j - 1].h = hNew;
                    cellDetails[i][j - 1].parent_i = i;
                    cellDetails[i][j - 1].parent_j = j;
                }
            }
        }
        iter++;
    }
    if (foundDest == false)
        printf("Failed to find the Destination Cell\n");
    return rest;
}

struct result best_destination(char a[21][49],struct pair src)  //esta funçao perece-me estar certa
{
    struct result best_ways[300];
    struct pair dest;
    int counter = 0;
    for (size_t i = 0; i < 21; i++)
    {
        for (size_t j = 0; j < 49; j++)
        {
            if (a[i][j] == '*')
            {
                dest.first = i; dest.second = j;
                best_ways[counter] = aStarSearch(a,src, dest);
                //printf("Custo: %d\n",best_ways[counter].cost);
                //printf("\n");
                counter++;
            }
        }
    }
    if(counter == 0){
        best_ways[0].cost = __INT_MAX__;
        return best_ways[0];
    }
    int ind = -1;
    int min = 9999999;
    for(size_t i=0; i<counter; i++){
        if(best_ways[i].cost<min){
            min = best_ways[i].cost;
            ind = i;
        }
    }
    //printf("Min = %d\n", min);

    return best_ways[ind];   //passa o custo do menor caminho e o percurso para o mesmo
}

void write_file()
{
    FILE *qfile;
    qfile = fopen("../agent/c2map.out", "w");
    for (size_t i = 0; i < 21; i++)
    {
        for (size_t j = 0; j < 49; j++)
        {   if (i==start_point.first & j == start_point.second+1)
        {
            fprintf(qfile, "%c", 'I');
        } else if(track[i][j] == '0') {
                fprintf(qfile, "%c", ' ');
        } else {
            fprintf(qfile, "%c", track[i][j]);}
        }
        fprintf(qfile, "%c", '\n');
    }
    fclose(qfile);
    return;
}

bool check_path(int d)
{
    ReadSensors();
    bool line[7];
    GetLineSensor(line);
    
    if(!line[2] && !line[3] && !line[4])
    { // não tem caminho para a frente
        switch (d)
        {
        case (1):
            ind_y--;
            track[ind_y - 1][ind_x] = '0';
            break;
        case (2):
            ind_x--;
            track[ind_y][ind_x - 1] = '0';
            break;
        case (0):
            ind_x++;
            track[ind_y][ind_x + 1] = '0';
            break;
        case (3):
            ind_y++;
            track[ind_y + 1][ind_x] = '0';
            break;
        }
        return true;
    }
    return false;
}

void go_find(struct result values, struct pair scr){
    ReadSensors();
    int d = direction(GetCompassSensor());
    go_objective(values.path[0].first,0);
    //print_values(values);
    //printf("Elements = %d\n",values.count);
    for(size_t i=0; i<=values.count; i++){
        go_objective(values.path[i].first, values.path[i].second);
        //printf("d = %d; cost = %d\n", values.path[i].first, values.path[i].second);
            
    }
    ReadSensors();
    d = direction(GetCompassSensor());
    //printf("(%d,%d) -> %d\n", ind_y, ind_x, d);
    if (d == 0)
    {
        ind_x--;
    }
    else if (d == 1)
    {
        ind_y++;
    }
    else if (d == 2)
    {
        ind_x++;
    }
    else if (d == 3)
    {
        ind_y--;
    }
    explore(d);
    DriveMotors(0,0);
    return;
}



